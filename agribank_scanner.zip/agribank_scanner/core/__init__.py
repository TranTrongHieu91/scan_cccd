"""
Core business logic package
Contains camera, QR, parser, and file management
"""