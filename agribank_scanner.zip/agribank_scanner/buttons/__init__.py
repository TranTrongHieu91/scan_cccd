"""
Button handlers package
Contains functionality for all application buttons
"""