"""
GUI panels package
Contains camera, data, and log panels
"""