"""
GUI dialogs package
Contains search, view, duplicate check, and camera fix dialogs
"""