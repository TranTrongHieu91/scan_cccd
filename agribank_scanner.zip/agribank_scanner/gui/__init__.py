"""
GUI package for AGRIBANK ID Scanner
Contains main window, panels, and dialogs
"""