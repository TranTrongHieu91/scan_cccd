"""
Database layer package
Contains search and record management functionality
"""